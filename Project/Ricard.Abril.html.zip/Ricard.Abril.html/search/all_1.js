var searchData=
[
  ['biblio_2ehh',['Biblio.hh',['../_biblio_8hh.html',1,'']]],
  ['biblioteca',['Biblioteca',['../class_biblioteca.html',1,'Biblioteca'],['../class_biblioteca.html#a5e12ea4e7a4edb14d210a41708fc1c10',1,'Biblioteca::Biblioteca()']]]
];

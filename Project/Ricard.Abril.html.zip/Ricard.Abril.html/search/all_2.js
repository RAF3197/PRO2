var searchData=
[
  ['cita',['Cita',['../class_cita.html',1,'Cita'],['../class_cita.html#a34ee157d8200bd19d33482aad17c0c09',1,'Cita::Cita()']]],
  ['cita_2ehh',['Cita.hh',['../_cita_8hh.html',1,'']]],
  ['cites',['cites',['../class_biblioteca.html#a4fb53dbb979ae36f389cf0054e278c18',1,'Biblioteca']]],
  ['citesautor',['citesAutor',['../class_biblioteca.html#a9be41f736af5791789750df6e24f24bf',1,'Biblioteca']]],
  ['consulta_5fauto',['consulta_auto',['../class_text.html#acedd24b9998f86f6ba211ec5a772aa35',1,'Text']]],
  ['consulta_5fcontingut',['consulta_contingut',['../class_text.html#ab7e8f95f2661c78c7c7878f23ddb6fda',1,'Text']]],
  ['conteparaules',['conteParaules',['../class_text.html#a0088d87c9d817b7423fe21c291d469d5',1,'Text']]],
  ['contingut',['contingut',['../class_biblioteca.html#ab3d96bec0fc25472bed0ed7fcb55e43e',1,'Biblioteca']]]
];

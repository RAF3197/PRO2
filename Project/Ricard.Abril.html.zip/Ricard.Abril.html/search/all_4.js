var searchData=
[
  ['frases',['frases',['../class_biblioteca.html#aa887655cea0fa0fdcdea193cf42fd9dc',1,'Biblioteca::frases()'],['../class_text.html#ac1213313a2d7972b691bdec87395b41c',1,'Text::frases()']]],
  ['frasesexpresio',['frasesexpresio',['../class_biblioteca.html#a00c494470f879afebf017ce8c5e6388d',1,'Biblioteca::frasesexpresio()'],['../class_text.html#a24aaf0c052ecb4bb834b70f986b3d80c',1,'Text::frasesexpresio()']]],
  ['frasesparaules',['frasesparaules',['../class_biblioteca.html#a683768fa88f07fc2ae3211523597b2f6',1,'Biblioteca::frasesparaules()'],['../class_text.html#a5ddb3098ba2318e27d8d28511b3aeee5',1,'Text::frasesparaules()']]]
];

var searchData=
[
  ['gestor_20de_20textos_20i_20cites_2e',['Gestor de textos i cites.',['../index.html',1,'']]]
];

var searchData=
[
  ['info',['info',['../class_biblioteca.html#a87408818e0025f8c97f1e5af1c3db4ad',1,'Biblioteca::info()'],['../class_cita.html#ac8662aa5e897dddaee3647ebc916b674',1,'Cita::info()'],['../class_text.html#a080d4e75020a9715df456c7ee32cf0b9',1,'Text::info()']]],
  ['infocita',['infocita',['../class_biblioteca.html#ad2a8b7d90fbc72527163ccc0a1eb6146',1,'Biblioteca']]],
  ['inicials',['inicials',['../class_autor.html#a5b7443138ae1a105d8435921ffd1f950',1,'Autor']]]
];

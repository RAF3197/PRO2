var searchData=
[
  ['nom',['nom',['../class_autor.html#aec1532555eea67b966a445ccb428dc58',1,'Autor']]],
  ['nombrefrases',['nombrefrases',['../class_biblioteca.html#af4c1d2463862366fcd0e745e0be07818',1,'Biblioteca']]],
  ['nombreparaules',['nombreparaules',['../class_biblioteca.html#a29870242ef9f63911e402da76c344800',1,'Biblioteca']]],
  ['num_5ffrases',['num_frases',['../class_text.html#ae16a541de4a146bb2ba6e648fa84f2ce',1,'Text']]],
  ['num_5fpar',['num_par',['../class_text.html#aeab5085af96c10dc48db02f871fc8590',1,'Text']]]
];

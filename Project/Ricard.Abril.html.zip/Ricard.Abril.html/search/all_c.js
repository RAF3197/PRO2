var searchData=
[
  ['tauladefrecuencies',['tauladefrecuencies',['../class_biblioteca.html#a13cb5edbdbdae403a164064a123fa995',1,'Biblioteca']]],
  ['taulafreq',['taulafreq',['../class_text.html#a124b917d4b414c09795f904abd056532',1,'Text']]],
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#ae463278cfe324ed63b5ae39ae7ac9dc8',1,'Text::Text()']]],
  ['text_2ehh',['Text.hh',['../_text_8hh.html',1,'']]],
  ['textosautor',['TextosAutor',['../class_biblioteca.html#ab354825e05c034ba0d381cacded6803d',1,'Biblioteca']]],
  ['tipus',['tipus',['../class_expressio.html#a527dffb75fb8d98c99b6bea744f44241',1,'Expressio']]],
  ['totescites',['totescites',['../class_biblioteca.html#a31e1326f8b0d520633c940704b13287d',1,'Biblioteca']]],
  ['totsautors',['TotsAutors',['../class_biblioteca.html#a92f95b9bdde385b51434d665ea87cef9',1,'Biblioteca']]],
  ['totstextos',['TotsTextos',['../class_biblioteca.html#a6dbb6b9d261285a7c3db0a50d2b902c6',1,'Biblioteca']]],
  ['triartext',['TriarText',['../class_biblioteca.html#a277efa643adc8466a0e90796b02fec5d',1,'Biblioteca']]],
  ['txt',['txt',['../class_cita.html#aa5f53fc5891fa5661298c0f13282697e',1,'Cita']]]
];

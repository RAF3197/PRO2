var searchData=
[
  ['afegircita',['afegircita',['../class_biblioteca.html#a4952a1efcc9cbec86090fb0b29280a47',1,'Biblioteca']]],
  ['afegirtext',['AfegirText',['../class_biblioteca.html#a92e0d87ad0f16a34789d6494f601bce7',1,'Biblioteca']]],
  ['autor',['Autor',['../class_autor.html#a81721f591da3585fd06ed269bad15fb8',1,'Autor::Autor()'],['../class_biblioteca.html#aaad59355b009b00dfea42c853c17f7d2',1,'Biblioteca::autor()']]]
];

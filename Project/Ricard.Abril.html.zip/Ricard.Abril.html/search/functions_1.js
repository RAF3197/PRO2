var searchData=
[
  ['biblioteca',['Biblioteca',['../class_biblioteca.html#a5e12ea4e7a4edb14d210a41708fc1c10',1,'Biblioteca']]]
];

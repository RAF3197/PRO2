var searchData=
[
  ['substitueix',['substitueix',['../class_text.html#a0d25f5164d62c928b1d4f7b009ef580a',1,'Text']]],
  ['subtext',['SubText',['../class_biblioteca.html#acbe2997c70008ebc318ef19ef2bd3fb7',1,'Biblioteca']]]
];

var searchData=
[
  ['_7eautor',['~Autor',['../class_autor.html#a65126632f45d86897faa0d2d10a40ef4',1,'Autor']]],
  ['_7ebiblioteca',['~Biblioteca',['../class_biblioteca.html#ae3f55e8952ed4bdddb82ece48c52f6c0',1,'Biblioteca']]],
  ['_7etext',['~Text',['../class_text.html#a2d49e5c280e205125b149f7777ae30c7',1,'Text']]]
];

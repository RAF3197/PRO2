#include "Text.hh"

struct aparicions{
	int vegades;
    vector<int> files;
};

bool comp(const pair<string, int>& elem1, const pair<string, int>& elem2){
	if (elem1.second == elem2.second){
		if (elem2.first.size() == elem1.first.size()){
			return elem2.first > elem1.first;
		}
		else return elem1.first.size() < elem2.first.size();
	}
	else return elem1.second > elem2.second;
}
Text::Text(){}
Text::Text(string titoltxt,string autortxt,vector<vector<string> > contingutaux){
    titol = titoltxt;
    autor = autortxt;
    contingut = contingutaux;
    string nomautor;
	istringstream issini(autortxt);
	while (issini >> nomautor){
		inicials_priv += nomautor[0];
	}

    string comanda = titoltxt;
	istringstream a1(comanda);
	while (a1 >> comanda){
		paraules.insert(comanda);
	}
	string autoraux = autortxt;
	istringstream a2(autoraux);
	while (a2 >> autoraux){
		paraules.insert(autoraux);
	}
	
	taulafrequs(contingutaux);

} 	

Text::~Text(){}
 

 /** @brief Comprovador de presència. 

      Mira si al text es troben les paraules desitjades
      \pre <em>cert</em>
      \post  retorna cert si es troba en el paràmetre implícit totes les paraules contingudes al vector, altrament, retorna fals.
  */         

void Text::taulafrequs (vector<vector<string> > continguttxt){//test this shit
	num_frases = 0;
	num_paraules = 0;
	map <string, aparicions > mapfreqaux;
    for (int i = 0; i < int(continguttxt.size()); ++i) {
        num_frases += 1;
	    for (int j = 0; j < int(continguttxt[i].size()); ++j){
		    string auxiliar = continguttxt[i][j];
		    char c = auxiliar[auxiliar.size()-1];
		    if (c == ',' or c == ';' or c == ':' or c == '.' or c == '?' or c == '!') auxiliar.erase(auxiliar.size()-1);
		    else {
		    	num_paraules += 1;
		    	map <string, aparicions>::iterator it = mapfreqaux.find(auxiliar) ;
		    	if (it != mapfreqaux.end()){
		   			vector<int> vaux = it->second.files;
		   			vaux.push_back(i+1);
		   			mapfreqaux[auxiliar].vegades +=1;
		   			mapfreqaux[auxiliar].files.resize(vaux.size());
		   			mapfreqaux[auxiliar].files = vaux;

				}
		    	else {
		    		mapfreqaux[auxiliar].vegades = 1; 
		    		vector<int> vaux;
		   			vaux.push_back(i+1);
		   			mapfreqaux[auxiliar].files.resize(vaux.size());
		    		mapfreqaux[auxiliar].files = vaux;
		    	}
		    	
		    }
		    
		    
		}
	}
	mapfreq = mapfreqaux;
	vector <pair<string,int> > taulafreqaux;
	for (map <string, aparicions >::iterator tfav = mapfreq.begin(); tfav != mapfreq.end(); ++tfav){
		taulafreqaux.push_back(make_pair(tfav->first,tfav->second.vegades));
	}
	taulafreq = taulafreqaux;
	sort (taulafreq.begin(), taulafreq.end(), comp);
}

void Text::substitueix(string paraula1, string paraula2){
	for (int i=0;i<int(contingut.size());++i){
		for (int j=0;j<int(contingut[i].size());++j){
			if (contingut[i][j] == paraula1){
				contingut[i][j] = paraula2;
			}
		}
	}
	taulafrequs(contingut);
}

bool Text::conteParaules(vector <string>paraulesbuscar){
	int conter = 0;
	for(int s = 0; s < int(paraulesbuscar.size()); ++s){
		if (mapfreq.find(paraulesbuscar[s]) != mapfreq.end() or  paraules.find(paraulesbuscar[s]) != paraules.end() ){
			conter += 1;
		}
	}
	if(conter == int(paraulesbuscar.size())) return true;
	else return false;
} 
void Text::afegircitaref(string ref){
	citesassoci.insert(ref);
}

void Text::conscitesasso(set<string>& citesu){
	citesu = citesassoci;
}

string Text::consulta_inicials()const{
		return inicials_priv;
	}

string Text::consulta_auto()const{
	    return autor;
	}

string Text::consulta_titol() const{
	  return titol;
	}

vector<vector<string> > Text::consulta_contingut()const{
    return contingut;
}

int Text::num_par(){
	return num_paraules;
}

int Text::numero_frases(){
	return num_frases;
}

vector <pair<string,int> > Text::taulafreqs(){
	return taulafreq;		
}

vector <int> Text::recursiva(string expre){
	int parob = 0;
	int partan = 0;
	int i = 0;
	string expdreta;
	string expesq;
	vector <int> vectr1;
	vector <int> vectr2;
	if (expre[i]=='{' and expre.find_first_of("}") == expre.size()-1){//cas base
		bool primer = true;
		expre.erase(0,1);
		expre.erase(expre.length()-1);
		vector<int> vect1;
		//cout << "aqui arriba 1" << endl;
		expremin(expre, vect1, primer);
		return vect1;
	}
	else {
		if (expre[i] == '(') {
			expre.erase(0,1);
			expre.erase(expre.length()-1);
			//cout << expre << endl;
			if (expre[i] == '('){
				//cout << "entra" <<endl;
				++parob;
				++i;
				while(i<int(expre.size()) and parob-partan != 0){
					if (expre[i]=='(')++parob;
					else if (expre[i]==')')++partan;
					++i;
					//cout << i <<endl;
				}
				expesq = expre.substr(0,i);//expre dreta
				//cout << expesq<< endl;
				expre.erase(0,i);
				char op;
				istringstream seop (expre);
				seop >> op; //operacio
				//cout << op<<endl;
				//cout <<expre<<endl;
				i = 0;
				while (expre[i] == ' ' or expre[i] == '&' or expre[i] == '|') ++i;
				expdreta = expre.substr(i,expre.size()-1);
				//cout << expdreta<<endl;
				if (op == '&'){
					vectr1 = recursiva(expesq);
					vectr2 = recursiva(expdreta);
					/*cout <<"antes"<<endl;
						for (int y = 0; y<vectr1.size();++y)cout <<vectr1[y]<<endl;
						for (int y = 0; y<vectr2.size();++y)cout <<vectr2[y]<<endl;*/
					interseccio(vectr1,vectr2);
					/*cout <<"despues"<<endl;
						for (int y = 0; y<vectr1.size();++y)cout <<vectr1[y]<<endl;
						for (int y = 0; y<vectr2.size();++y)cout <<vectr2[y]<<endl;
							cout << "end" <<endl;*/
					return vectr1;
				}
				else if (op == '|'){
					vectr1 = recursiva(expesq);
					vectr2 = recursiva(expdreta);
					/*cout <<"antes"<<endl;
						for (int y = 0; y<vectr1.size();++y)cout <<vectr1[y]<<endl;
						for (int y = 0; y<vectr2.size();++y)cout <<vectr2[y]<<endl;*/
					unio(vectr1, vectr2);
					/*cout <<"despues"<<endl;
						for (int y = 0; y<vectr1.size();++y)cout <<vectr1[y]<<endl;
						for (int y = 0; y<vectr2.size();++y)cout <<vectr2[y]<<endl;
							cout << "end" <<endl;*/
					return vectr1;
				}

			}
			else if (expre[i] == '{'){
				i = expre.find_first_of("(");
				//cout << i << endl;//chiv
				if (i == -1){
					i = expre.find_first_of("}");
					//cout << i << endl;//chiv
					expesq = expre.substr(0, i+1);
					//cout << expesq <<endl;
					expre.erase(0,i+1);
					//cout << expre <<endl;
					char op;
					istringstream seop (expre);
					seop >> op; //operacio
					//cout << op <<endl; //chiv
					i = 0;
					while (expre[i] == ' ' or expre[i] == '&' or expre[i] == '|') ++i;
					expdreta = expre.substr(i,expre.size()-1);
					//cout << expdreta<<endl;
					if (op == '&'){
						vectr1 = recursiva(expesq);
						vectr2 = recursiva(expdreta);
						interseccio(vectr1, vectr2);
						
					}
					else if (op == '|'){
						vectr1 = recursiva(expesq);
						vectr2 = recursiva(expdreta);
						/*cout <<"antes"<<endl;
						for (int y = 0; y<vectr1.size();++y)cout <<vectr1[y]<<endl;
						for (int y = 0; y<vectr2.size();++y)cout <<vectr2[y]<<endl;*/
						unio(vectr1, vectr2);
						/*cout <<"despues"<<endl;
						for (int y = 0; y<vectr1.size();++y)cout <<vectr1[y]<<endl;
						for (int y = 0; y<vectr2.size();++y)cout <<vectr2[y]<<endl;
							cout << "end" <<endl;*/
					}
					return vectr1;

				}
				else {
					expesq = expre.substr(i, expre.size()-1);
					expre.erase(i, expre.size()-1);
					i = expre.find_last_of("}");
					expdreta = expre.substr(0, i);
					expre.erase(0, i);
					char op;
					istringstream seop (expre);
					seop >> op;
					if (op == '&'){
						vectr1 = recursiva(expesq);
						vectr2 = recursiva(expdreta);
						interseccio(vectr1, vectr2);
						
					}
					else if (op == '|'){
						vectr1 = recursiva(expesq);
						vectr2 = recursiva(expdreta);
						unio(vectr1, vectr2);
					}
					return vectr1;
				}
				
			}

		}

	}
	vector <int> vecreturn = vectr1;
	return vecreturn;
}


void Text::expremin(string expres, vector<int> &vect1, bool &primer){
	string word;
	istringstream anali (expres);
	bool falta = false;
	//cout<<word<<endl;//borrar
	/*size_t found = expres.find("}"); //separar } de la palabra anterior o crear un espacio más, así podemos utilizar el while de más abajo
	while (found != string::npos){
		expres.replace(found, 1, " } ");
		found =expres.find("}", found+3);
	}*/
	while (anali >> word and not falta){
		vector <int> vect2;
		map<string, aparicions>::iterator tosearch = mapfreq.find(word);
		if (tosearch == mapfreq.end()){
			if (word == "&"){}
			else {
				falta = true;
				vect1.clear(); //en el caso que la palabra no este, borramos el vector a devolver
			}
		}
		else {
			vect2 = tosearch->second.files;
			//for (int q = 0; q<vect2.size();++q) cout << vect2[q] << ' ';
			//cout<<endl;
			//for (int q = 0; q<vect1.size();++q) cout << vect1[q] << ' ';
			//cout<<endl;
			if (primer){
				unio(vect1, vect2);
				//cout << "aqui arriba 2" << endl;	
				primer = false;
			}
			else interseccio(vect1, vect2);
			//cout << "aqui arriba 3" << endl;
		}
	}
	//if (falta) cout << "falta" <<endl;
	//for (int p = 0; p<vect1.size();++p) cout << vect1[p] << "hola"<< endl;
}
void Text::frasesparaules(vector<string> paraulests, vector<int> &vect1){
	bool falta = false;
	bool primer = true;
	int d = 0;
	while (d < int(paraulests.size()) and not falta){
		map <string, aparicions >::iterator freqit = mapfreq.find(paraulests[d]);
		if (freqit == mapfreq.end())falta = true;
		else{
			vector<int> vect2 = freqit->second.files;
			if (primer) {
				unio(vect1, vect2);
				primer = false;
			}
			else interseccio(vect1, vect2);
		}
		++d;
	}
	if (falta) vect1.clear();
	else {
		for (int t = 0; t < int(vect1.size()); ++t){//lectura del vetor que indica las frases a buscar
			int l = 0; //lincado con paraulests
			int m = 0; //lincado con contingut
			bool erroni = false;
			bool primerapara = false;
			while (l < int(paraulests.size()) and m < int(contingut[vect1[t]-1].size()) and not erroni){
				char caux = contingut[vect1[t]-1][m][0];
				if (caux == '.' or caux == ',' or caux == ';' or caux == '?' or caux == '!') {
					++m;
				}
				else if (contingut[vect1[t]-1][m] != paraulests[l] and not primerapara) ++m;
				else if (contingut[vect1[t]-1][m] != paraulests[l] and primerapara) erroni = true;
				else if (contingut[vect1[t]-1][m] == paraulests[l]){
					primerapara = true;
					++l;
					++m;
				}
			}
			if (l < int(paraulests.size())) erroni = true;
			if (not erroni) {
				bool primertp = true;
			    bool ultimtp = false;
			    cout << vect1[t] << " ";
			    for (int p = 0; p < int(contingut[vect1[t]-1].size()); ++p){
			      bool puntuacio =false;
			      if (p == int(contingut[vect1[t]-1].size()-1)) {ultimtp = true;}
			      if (contingut[vect1[t]-1][p] == "," or contingut[vect1[t]-1][p] == ";" or contingut[vect1[t]-1][p] == ":") puntuacio = true;
			      if (primertp){
			        primertp = false;
			        cout << contingut[vect1[t]-1][p];
			      }
			      else if (ultimtp) cout << contingut[vect1[t]-1][p];
			      else if (puntuacio) cout << contingut[vect1[t]-1][p];
			      else cout<<" "<<contingut[vect1[t]-1][p];
			    }
			    cout <<endl;
			}
		}
	}//*/
}

void Text::interseccio (vector<int> &vec1, vector<int> &vec2){
  vector<int> v3;
  int i = 0;
  int j = 0;
  while (i < int(vec1.size()) and j < int(vec2.size())){
    if (vec1[i] < vec2[j]) ++i;
    else if (vec1[i] > vec2[j]) ++j;
    else if (vec1[i] == vec2[j]){
      v3.push_back(vec1[i]);
      ++i;
      ++j;
    }
  }
  vec1 = v3;
}

void Text::unio (vector<int> &vec1, vector<int> &vec2){
  vector<int> v3;
  int j = 0;
  int i = 0;
  while (i < int(vec1.size()) and j < int(vec2.size())){
    if (vec1[i] < vec2[j]) {
      v3.push_back(vec1[i]);
      ++i;
    }
    else if (vec1[i] > vec2[j]){
      v3.push_back(vec2[j]);
      ++j;
    }
    else if (vec1[i] == vec2[j]){
      v3.push_back(vec1[i]);
      ++i;
      ++j;
    }
  }
  if (i == int(vec1.size()) and j < int(vec2.size())){
    for (int k = j; k < int(vec2.size()); ++k){
      v3.push_back(vec2[k]);
    }  
  }
  else if (i < int(vec1.size()) and j == int(vec2.size())){
    for (int k = i; k < int(vec1.size()); ++k){
      v3.push_back(vec1[k]);
    }
  }
  vec1 = v3; 
}

void Text::elim_cit_set(const string &referencia){
	citesassoci.erase(referencia);
}